export default function Home() {
  return (
    <section className="min-h-screen bg-sky-100 text-gray-900">
      <div className="container mx-auto px-6 py-24 text-center">
        <h1 className="text-5xl font-bold mb-6">
          Empowering Generations, Transforming Communities
        </h1>
        <p className="text-lg mb-8">
          A youth-led nonprofit focused on education, family support, and community transformation.
        </p>
        <div className="flex justify-center space-x-4">
          <a href="/programs" className="bg-yellow-500 text-white px-6 py-3 rounded-full hover:bg-yellow-600 transition">
            Our Programs
          </a>
          <a href="/involved" className="text-yellow-500 border border-yellow-500 px-6 py-3 rounded-full hover:bg-yellow-100 transition">
            Get Involved
          </a>
        </div>
      </div>
    </section>
  );
}
